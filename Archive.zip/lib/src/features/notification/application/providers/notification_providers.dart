import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:kc_app/src/core/errors/failure_mapper.dart';
import 'package:kc_app/src/core/providers/firebase_providers.dart';
import 'package:kc_app/src/features/boutique/application/providers/boutique_providers.dart';
import 'package:kc_app/src/features/notification/data/repositories/notification_firestore_repository.dart';
import 'package:kc_app/src/features/notification/data/services/firebase_messaging_service.dart';
import 'package:kc_app/src/features/notification/domain/models/notification_model.dart';
import 'package:kc_app/src/features/notification/domain/models/notification_permission_state.dart';

// ─────────────────────────────────────────────
// Repository & Service providers
// ─────────────────────────────────────────────

final notificationRepositoryProvider =
    Provider<NotificationFirestoreRepository>((ref) {
      return NotificationFirestoreRepository(
        firestore: ref.watch(firebaseFirestoreProvider),
      );
    });

final firebaseMessagingServiceProvider = Provider<FirebaseMessagingService>((
  ref,
) {
  return FirebaseMessagingService();
});

// ─────────────────────────────────────────────
// Notification Permission Notifier
// ─────────────────────────────────────────────

final notificationPermissionProvider =
    NotifierProvider<
      NotificationPermissionNotifier,
      NotificationPermissionState
    >(NotificationPermissionNotifier.new);

class NotificationPermissionNotifier
    extends Notifier<NotificationPermissionState> {
  @override
  NotificationPermissionState build() {
    Future.microtask(() => checkPermissionStatus());
    return const NotificationPermissionState.unknown();
  }

  Future<void> checkPermissionStatus() async {
    try {
      final status = await Permission.notification.status;
      if (status.isGranted) {
        state = const NotificationPermissionState.granted();
      } else if (status.isPermanentlyDenied) {
        state = const NotificationPermissionState.denied();
      } else {
        // isDenied or not requested yet -> prompt user!
        state = const NotificationPermissionState.notRequested();
      }
    } catch (e, st) {
      state = NotificationPermissionState.failure(FailureMapper.map(e, st));
    }
  }

  Future<void> requestPermission({String? customerId}) async {
    if (state is NotificationPermissionRequesting) return;
    state = const NotificationPermissionState.requesting();

    try {
      final service = ref.read(firebaseMessagingServiceProvider);
      final settings = await service.requestPermission();

      if (settings.authorizationStatus == AuthorizationStatus.authorized ||
          settings.authorizationStatus == AuthorizationStatus.provisional) {
        state = const NotificationPermissionState.granted();
        if (customerId != null && customerId.isNotEmpty) {
          await service.initialize(
            customerId: customerId,
            firebaseUid: customerId,
          );
        }
      } else if (settings.authorizationStatus == AuthorizationStatus.denied) {
        state = const NotificationPermissionState.denied();
      } else {
        state = const NotificationPermissionState.notRequested();
      }
    } catch (e, st) {
      state = NotificationPermissionState.failure(FailureMapper.map(e, st));
    }
  }
}

// ─────────────────────────────────────────────
// Notification list — live stream
// ─────────────────────────────────────────────

final notificationListProvider = StreamProvider<List<NotificationModel>>((ref) {
  final boutiqueId =
      ref.watch(selectedBoutiqueProvider)?.id ??
      ref.watch(autoSelectedBoutiqueProvider)?.id ??
      'boutique_01';
  return ref
      .watch(notificationRepositoryProvider)
      .watchNotifications(boutiqueId);
});

/// Unread notification count for badge on header bell icon.
final unreadNotificationCountProvider = Provider<int>((ref) {
  final list = ref.watch(notificationListProvider).valueOrNull ?? [];
  return list.where((n) => n.status == NotificationStatus.published).length;
});

// ─────────────────────────────────────────────
// Filter state
// ─────────────────────────────────────────────

enum NotificationReadFilter { all, unread, read }

class NotificationFilterState {
  const NotificationFilterState({
    this.searchQuery = '',
    this.typeFilter,
    this.statusFilter,
    this.audienceFilter,
    this.readFilter = NotificationReadFilter.all,
  });

  final String searchQuery;
  final NotificationType? typeFilter;
  final NotificationStatus? statusFilter;
  final NotificationAudienceType? audienceFilter;
  final NotificationReadFilter readFilter;

  NotificationFilterState copyWith({
    String? searchQuery,
    Object? typeFilter = _sentinel,
    Object? statusFilter = _sentinel,
    Object? audienceFilter = _sentinel,
    NotificationReadFilter? readFilter,
  }) => NotificationFilterState(
    searchQuery: searchQuery ?? this.searchQuery,
    typeFilter: typeFilter == _sentinel
        ? this.typeFilter
        : typeFilter as NotificationType?,
    statusFilter: statusFilter == _sentinel
        ? this.statusFilter
        : statusFilter as NotificationStatus?,
    audienceFilter: audienceFilter == _sentinel
        ? this.audienceFilter
        : audienceFilter as NotificationAudienceType?,
    readFilter: readFilter ?? this.readFilter,
  );
}

const _sentinel = Object();

final notificationFilterProvider =
    NotifierProvider<NotificationFilterNotifier, NotificationFilterState>(
      NotificationFilterNotifier.new,
    );

class NotificationFilterNotifier extends Notifier<NotificationFilterState> {
  @override
  NotificationFilterState build() => const NotificationFilterState();

  void search(String q) => state = state.copyWith(searchQuery: q.trim());

  void filterByType(NotificationType? t) =>
      state = state.copyWith(typeFilter: t);

  void filterByStatus(NotificationStatus? s) =>
      state = state.copyWith(statusFilter: s);

  void filterByAudience(NotificationAudienceType? a) =>
      state = state.copyWith(audienceFilter: a);

  void filterByRead(NotificationReadFilter r) =>
      state = state.copyWith(readFilter: r);

  void reset() => state = const NotificationFilterState();
}

// ─────────────────────────────────────────────
// Derived: filtered notification list
// ─────────────────────────────────────────────

final filteredNotificationListProvider = Provider<List<NotificationModel>>((
  ref,
) {
  final all = ref.watch(notificationListProvider).valueOrNull ?? [];
  final filter = ref.watch(notificationFilterProvider);

  var result = all.where((n) {
    if (filter.typeFilter != null && n.type != filter.typeFilter) return false;
    if (filter.statusFilter != null && n.status != filter.statusFilter) {
      return false;
    }
    if (filter.audienceFilter != null &&
        n.audienceType != filter.audienceFilter) {
      return false;
    }
    if (filter.searchQuery.isNotEmpty) {
      final q = filter.searchQuery.toLowerCase();
      return n.title.toLowerCase().contains(q) ||
          n.body.toLowerCase().contains(q);
    }
    return true;
  }).toList();

  result.sort((a, b) {
    final at = a.scheduledAt ?? a.publishedAt ?? a.createdAt;
    final bt = b.scheduledAt ?? b.publishedAt ?? b.createdAt;
    return bt.compareTo(at);
  });

  return result;
});

// ─────────────────────────────────────────────
// Mutation notifier (admin)
// ─────────────────────────────────────────────

final notificationMutationProvider =
    NotifierProvider<NotificationMutationNotifier, AsyncValue<void>>(
      NotificationMutationNotifier.new,
    );

class NotificationMutationNotifier extends Notifier<AsyncValue<void>> {
  @override
  AsyncValue<void> build() => const AsyncValue.data(null);

  NotificationFirestoreRepository get _repo =>
      ref.read(notificationRepositoryProvider);

  Future<void> create(NotificationModel notification) async {
    state = const AsyncValue.loading();
    state = await AsyncValue.guard(
      () => _repo.createNotification(notification),
    );
    if (!state.hasError) ref.invalidate(notificationListProvider);
  }

  Future<void> update(NotificationModel notification) async {
    state = const AsyncValue.loading();
    state = await AsyncValue.guard(
      () => _repo.updateNotification(notification),
    );
    if (!state.hasError) ref.invalidate(notificationListProvider);
  }

  Future<void> markAsRead(String notificationId, String customerId) async {
    state = const AsyncValue.loading();
    state = await AsyncValue.guard(
      () => _repo.markAsRead(notificationId, customerId),
    );
  }
}
