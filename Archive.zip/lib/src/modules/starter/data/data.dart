// Starter module data exports
